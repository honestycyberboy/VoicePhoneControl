# Voice Phone Control (for HUAWEI nova Y70 · EMUI 12 · Android 10)

Say "phone <command>" and the phone does it.

    mic -> Vosk (offline speech-to-text) -> Claude (decides next step from the screen)
        -> Accessibility service (tap / type / scroll / open app / back / home)

## Why these choices (your phone)
- nova Y70 ships without Google services, so Google's SpeechRecognizer and Assistant are unreliable.
  Vosk runs fully offline and needs no Google/Huawei account.
- EMUI 12 = Android 10, so targetSdk is 29, minSdk 26.
- Accessibility Service is the only no-root way to read the screen and tap for the user.

## Setup
1. Open the folder in Android Studio, let Gradle sync, build and install on the phone (USB debugging).
2. Download `vosk-model-small-en-us-0.15` from alphacephei.com/vosk/models, unzip it, and copy the
   unzipped contents into a folder named `model` at:
   `/sdcard/Android/data/com.example.voicecontrol/files/model`
   (the app shows this path on its main screen; `model/` must directly contain `am/`, `conf/`, `graph/`...).
3. Open the app: paste your Anthropic API key, tap Save.
4. Tap "Enable accessibility service" -> Voice Phone Control -> turn on.
5. Tap "Start listening".

## Huawei-specific: keep it alive
Settings -> Battery -> App launch -> Voice Phone Control -> Manage manually -> enable all three
(Auto-launch, Secondary launch, Run in background). Also lock the app in Recents.

## Try
"phone open settings" · "phone scroll down" · "phone go back" · "phone open chrome and search for weather"

## Limits / next steps
- Small Vosk model mishears sometimes; wake word is plain "phone". Swap for a custom wake-word engine later.
- Uses a text description of the screen. Apps that hide content from accessibility (games, some banking apps) won't work.
- API key is stored on-device; for anything you ship, call Claude through your own server instead.
- Add a spoken/visual confirmation step before sends, payments and deletions (the prompt already tells the model to ask).
- Does not work on the lock screen; unlock first.

## Build without Android Studio (GitHub Actions)
Upload this whole folder (including the hidden .github folder) to a new GitHub repo.
Actions tab -> "Build APK" -> open the finished run -> download artifact "VoicePhoneControl-apk" -> unzip -> install app-debug.apk.
