plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.voicecontrol"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.voicecontrol"
        minSdk = 26
        targetSdk = 29          // your nova Y70 runs EMUI 12 = Android 10 (API 29)
        versionCode = 1
        versionName = "0.1"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("com.alphacephei:vosk-android:0.3.47")   // offline speech-to-text, no Google services needed
    implementation("net.java.dev.jna:jna:5.13.0@aar")
}
