package com.example.voicecontrol

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** The "hands": reads the screen and performs taps, typing, scrolling and navigation. */
class VoiceControlService : AccessibilityService() {

    companion object { @Volatile var instance: VoiceControlService? = null }

    private val nodes = mutableListOf<AccessibilityNodeInfo>()

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** Numbered list of what is on screen, e.g. "3|button|Settings". */
    fun snapshot(): String {
        nodes.clear()
        val root = rootInActiveWindow ?: return "(no screen content)"
        val sb = StringBuilder()
        walk(root, sb)
        return sb.toString().ifBlank { "(empty screen)" }
    }

    private fun walk(n: AccessibilityNodeInfo, sb: StringBuilder) {
        if (nodes.size >= 80) return
        val label = (n.text ?: n.contentDescription)?.toString()?.replace("\n", " ")?.take(60)
        val interesting = n.isClickable || n.isEditable || !label.isNullOrBlank()
        if (n.isVisibleToUser && interesting) {
            val kind = when { n.isEditable -> "input"; n.isClickable -> "button"; else -> "text" }
            sb.append(nodes.size).append('|').append(kind).append('|').append(label ?: "").append('\n')
            nodes.add(n)
        }
        for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it, sb) }
    }

    fun click(id: Int): Boolean {
        var t: AccessibilityNodeInfo? = nodes.getOrNull(id)
        while (t != null && !t.isClickable) t = t.parent
        return t?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }

    fun type(text: String, id: Int? = null): Boolean {
        val target = id?.let { nodes.getOrNull(it) }
            ?: findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: nodes.firstOrNull { it.isEditable }
            ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun scroll(down: Boolean): Boolean {
        val s = nodes.firstOrNull { it.isScrollable } ?: rootInActiveWindow ?: return false
        return s.performAction(
            if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        )
    }

    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun recents() = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun notifications() = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    fun openApp(label: String): Boolean {
        val pm = packageManager
        val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(launch, 0)
            .firstOrNull { it.loadLabel(pm).toString().equals(label, ignoreCase = true) }
            ?: pm.queryIntentActivities(launch, 0)
                .firstOrNull { it.loadLabel(pm).toString().contains(label, ignoreCase = true) }
            ?: return false
        val i = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        return true
    }
}
