package com.example.voicecontrol

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** The "brain": sends the command + current screen to Claude, gets back ONE action as JSON. */
object Brain {
    private const val MODEL = "claude-haiku-5-5"

    private val SYSTEM = """
You control an Android phone for the user. You see the current screen as lines "id|kind|label".
Reply with ONE JSON object only, no other text. Allowed actions:
{"action":"open_app","name":"<app label>"}
{"action":"click","id":<int>}
{"action":"type","text":"<text>","id":<int, optional>}
{"action":"scroll","direction":"down"|"up"}
{"action":"back"} {"action":"home"} {"action":"recents"} {"action":"notifications"}
{"action":"done","message":"<short summary>"}
Rules: take the smallest next step toward the command. When the command is complete, reply done.
Never complete payments, purchases, deletions or sends of messages/emails unless the command
clearly says so; if unsure reply {"action":"done","message":"Need confirmation: ..."}.
""".trimIndent()

    fun decide(apiKey: String, command: String, screen: String, history: List<String>): JSONObject {
        val user = "Command: $command\n\nActions so far:\n${history.joinToString("\n").ifBlank { "(none)" }}\n\nScreen:\n$screen"
        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 200)
            .put("system", SYSTEM)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", user)))

        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000; c.readTimeout = 30000
        c.setRequestProperty("content-type", "application/json")
        c.setRequestProperty("x-api-key", apiKey)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.doOutput = true
        c.outputStream.use { it.write(body.toString().toByteArray()) }

        val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
        val resp = stream.bufferedReader().readText()
        if (c.responseCode !in 200..299) return JSONObject().put("action", "done").put("message", "API error ${c.responseCode}")

        val text = JSONObject(resp).getJSONArray("content").getJSONObject(0).getString("text")
        val s = text.indexOf('{'); val e = text.lastIndexOf('}')
        return JSONObject(text.substring(s, e + 1))
    }
}
