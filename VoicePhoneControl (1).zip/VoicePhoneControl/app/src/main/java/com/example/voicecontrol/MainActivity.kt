package com.example.voicecontrol

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    companion object { @Volatile var status = "Idle" }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }

        val key = EditText(this).apply { hint = "Anthropic API key"; setText(prefs.getString("key", "")) }
        val save = Button(this).apply { text = "Save key" }
        val a11y = Button(this).apply { text = "1. Enable accessibility service" }
        val start = Button(this).apply { text = "2. Start listening" }
        val stop = Button(this).apply { text = "Stop listening" }
        val info = TextView(this).apply {
            text = "Say: \"phone open settings\", \"phone scroll down\", \"phone go back\"\n\n" +
                   "Model files go in:\n${getExternalFilesDir(null)}/model"
        }
        val st = TextView(this)
        listOf(key, save, a11y, start, stop, info, st).forEach { col.addView(it) }
        setContentView(ScrollView(this).apply { addView(col) })

        save.setOnClickListener { prefs.edit().putString("key", key.text.toString().trim()).apply() }
        a11y.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        start.setOnClickListener {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            else startForegroundService(Intent(this, ListenService::class.java))
        }
        stop.setOnClickListener { stopService(Intent(this, ListenService::class.java)) }

        st.post(object : Runnable { override fun run() { st.text = "Status: $status"; st.postDelayed(this, 700) } })
    }
}
