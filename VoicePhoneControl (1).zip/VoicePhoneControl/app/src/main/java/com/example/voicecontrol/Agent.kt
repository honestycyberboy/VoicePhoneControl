package com.example.voicecontrol

import android.content.Context
import android.util.Log

/** Runs a spoken command as a short loop: look at screen -> ask Claude -> act -> repeat. */
object Agent {
    @Volatile private var busy = false

    fun run(ctx: Context, command: String, onStatus: (String) -> Unit) {
        if (busy) return
        val key = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE).getString("key", "") ?: ""
        val svc0 = VoiceControlService.instance
        if (key.isBlank() || svc0 == null) { onStatus("Set API key and enable accessibility service"); return }
        busy = true
        Thread {
            try {
                val history = mutableListOf<String>()
                repeat(8) { step ->
                    val svc = VoiceControlService.instance ?: return@Thread
                    val a = Brain.decide(key, command, svc.snapshot(), history)
                    Log.d("Agent", "step $step: $a")
                    val ok = when (a.optString("action")) {
                        "open_app" -> svc.openApp(a.getString("name"))
                        "click" -> svc.click(a.getInt("id"))
                        "type" -> svc.type(a.getString("text"), if (a.has("id")) a.getInt("id") else null)
                        "scroll" -> svc.scroll(a.optString("direction") == "down")
                        "back" -> svc.back()
                        "home" -> svc.home()
                        "recents" -> svc.recents()
                        "notifications" -> svc.notifications()
                        else -> { onStatus(a.optString("message", "Done")); return@Thread }
                    }
                    history.add("$a -> ${if (ok) "ok" else "failed"}")
                    Thread.sleep(1500)   // let the screen settle
                }
                onStatus("Stopped after 8 steps")
            } catch (e: Exception) {
                onStatus("Error: ${e.message}")
            } finally { busy = false }
        }.start()
    }
}
