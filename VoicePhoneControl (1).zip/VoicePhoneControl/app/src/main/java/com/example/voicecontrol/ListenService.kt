package com.example.voicecontrol

import android.app.*
import android.content.Intent
import android.os.IBinder
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File

/** Always-listening foreground service. Say: "phone open whatsapp", "phone scroll down", ... */
class ListenService : Service(), RecognitionListener {

    private var speech: SpeechService? = null
    private val wake = "phone"

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        val ch = "listen"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "Listening", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch)
            .setContentTitle("Voice Phone Control")
            .setContentText("Listening for \"$wake ...\"")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        startForeground(1, n)

        val modelDir = File(getExternalFilesDir(null), "model")
        if (!modelDir.exists()) { stopSelf(); return }
        Thread {
            val model = Model(modelDir.path)
            speech = SpeechService(Recognizer(model, 16000f), 16000f).also { it.startListening(this) }
        }.start()
    }

    override fun onResult(hypothesis: String?) {
        val text = JSONObject(hypothesis ?: return).optString("text").trim()
        if (text.isEmpty()) return
        val words = text.split(" ")
        val i = words.indexOf(wake)
        if (i >= 0 && i < words.size - 1) {
            val command = words.drop(i + 1).joinToString(" ")
            Agent.run(this, command) { MainActivity.status = it }
        }
    }

    override fun onFinalResult(h: String?) { onResult(h) }
    override fun onPartialResult(h: String?) {}
    override fun onError(e: Exception?) { MainActivity.status = "Mic error: ${e?.message}" }
    override fun onTimeout() {}

    override fun onDestroy() { speech?.stop(); speech?.shutdown() }
}
